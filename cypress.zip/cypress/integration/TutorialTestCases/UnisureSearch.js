import { createJSDocTypeExpression } from "typescript"


describe('UniSure Test Searching By Partial Reference', () => {

    
    it('When i get on a homepage, I should be able to search a quote successfully using a reference number', () => {
    cy.visit('https://quotes.test.uinsure.co.uk')
    //cy.uinsurelogin('john.doe@uinsure.co.uk','Password2')
     cy.log('Unisure Page Dashboard Displayed Successfully')
     cy.get('#cookieBar > .MuiContainer-root')
     cy.url().should('contains','/new-quote');
     cy.wait(5000)
     cy.get('[data-testid=nav-drawer-item-recent-activity-label]').click()
     cy.url().should('contains', '/retrieve-quote');
     cy.get('#policy-number').type('0657')
cy.get('[data-testid="filter-button"]').click()
cy.wait(5000)
//This line of code checks a particular text/data from the test data tag within the table
cy.get('table.MuiTable-root').contains('td','0657').should('be.visible')
//This line of code checks the 
cy.get('[data-testid=retrieve-quote-table-body] > :nth-child(n) > :nth-child(1)').contains('0657')
cy.get('[data-testid="show-more-button"]')


let buttonCount = 0;
while(buttonCount <= 20)
{

        Cypress.$('#gatsby-focus-wrapper > div > div > main > div > div > div > div.MuiBox-root.jss821 > button').click()
    
       // cy.get('[data-testid="show-more-button"]').click()
        buttonCount++;
        cy.log(buttonCount)
       
    }

    



       
})

})